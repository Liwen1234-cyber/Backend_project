create
    definer = root@`%` procedure p7(IN n int)
begin
    declare res int default 0;
    while n > 0 do
        set res := res + n;
        set n := n - 1;
        end while;
    select res;
end;

