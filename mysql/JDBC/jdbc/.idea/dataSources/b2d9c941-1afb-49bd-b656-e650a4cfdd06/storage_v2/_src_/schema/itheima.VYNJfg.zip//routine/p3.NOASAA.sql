create
    definer = root@`%` procedure p3()
begin
    declare score int default 58;
    declare result varchar(10) character set utf8;
    if score >= 85 then
        set result := '优秀';
    elseif score >= 60 then
        set result := '及格';
    else
        set result := '不及格';
    end if;

    select result;
end;

