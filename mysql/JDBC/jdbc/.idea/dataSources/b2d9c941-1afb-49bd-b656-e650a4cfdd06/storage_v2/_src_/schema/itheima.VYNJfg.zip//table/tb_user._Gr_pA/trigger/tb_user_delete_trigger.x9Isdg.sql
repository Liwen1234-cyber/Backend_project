create definer = root@`%` trigger tb_user_delete_trigger
    after delete
    on tb_user
    for each row
begin
insert into user_logs(id, operation, operate_time, operate_id, operate_params)
VALUES (null, 'delete', now(), old.id,
concat('删除之前的数据: id=',old.id,',name=',old.name, ', phone=', old.phone, ', email=', old.email, ', profession=', old.profession));
end;

