create definer = root@`%` trigger tb_user_update_trigger
    after update
    on tb_user
    for each row
begin
    insert into user_logs (id, operation, operate_time, operate_id, operate_params)
        VALUES (null, 'insert', now(), new.id,
                concat('更新前的数据内容为: id=',OLD.id,',name=',OLD.name, ', phone=', OLD.phone, ', email=', OLD.email, ', profession=', OLD.profession,
                '更新后的数据内容为: id=',new.id,',name=',new.name, ', phone=', NEW.phone, ', email=', NEW.email, ', profession=', NEW.profession));
end;

